#include <LiquidCrystal.h>
#include <Servo.h>
LiquidCrystal lcd(12, 11, 5, 4, 3, 2);
Servo lockServo;

const int trigPin = 10;
const int echoPin = 7; 
const int buttonPin = 8;

int totalSavings = 0;

void setup() {
  lcd.begin(16, 2);
  lockServo.attach(9);
  lockServo.write(0);
  
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
  pinMode(buttonPin, INPUT_PULLUP);

  lcd.print("Celengan Digital");
  lcd.setCursor(0, 1);
  lcd.print("Indo Emas 2030");
  delay(2000);
  updateLCD();
}

void loop() {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  
  long duration = pulseIn(echoPin, HIGH);
  int distance = duration * 0.034 / 2;

  if (distance > 0 && distance < 7) {
    totalSavings += 500;
    lcd.clear();
    lcd.print("Uang Masuk!");
    delay(1000);
    updateLCD();
  }

  if (digitalRead(buttonPin) == LOW) {
    lcd.clear();
    lcd.print("Membuka...");
    lockServo.write(90);
    delay(3000);
    lockServo.write(0);
    updateLCD();
  }
}

void updateLCD() {
  lcd.clear();
  lcd.print("Saldo Anda:");
  lcd.setCursor(0, 1);
  lcd.print("Rp. "); lcd.print(totalSavings);
}